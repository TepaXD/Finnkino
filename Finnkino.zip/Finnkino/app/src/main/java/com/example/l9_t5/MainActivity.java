package com.example.l9_t5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

interface MainInterface {
    void spinnerAdd(ArrayList theatre_array);
    void getArray(ArrayList<Theatre> arrayList);
    void showsAdd(ArrayList arrayList, String start_time, String end_time, String showName);

}

public class MainActivity extends AppCompatActivity implements MainInterface {

    EditText nameInput;
    EditText dateInput;
    EditText startTimeInput;
    EditText endTimeInput;
    Spinner movieSpinner;
    ListView shows;
    Button search;
    ArrayList<Theatre> theatre_array = new ArrayList<>();
    ArrayList<Show> show_array = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*ImageView myimageview = (ImageView) findViewById(R.id.imageView);
        myimageview.setImageResource(R.drawable.finnkinologo);*/
        setContentView(R.layout.activity_main);
        nameInput = (EditText) findViewById(R.id.name);
        dateInput = (EditText) findViewById(R.id.date);
        startTimeInput = (EditText) findViewById(R.id.starttime);
        endTimeInput = (EditText) findViewById(R.id.endtime);
        movieSpinner = (Spinner) findViewById(R.id.movies);
        shows = (ListView) findViewById(R.id.shows);
        search = (Button) findViewById(R.id.search);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        shows.setBackgroundResource(R.drawable.list_shape);
        new ReaderXML_Theatre(this).execute();


    }


    @Override
    public void spinnerAdd(ArrayList theatre_array) {
        ArrayAdapter<Theatre> adapter = new ArrayAdapter<Theatre>(this, R.layout.spinner_style, theatre_array);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        movieSpinner.setAdapter(adapter);
    }

    @Override
    public void getArray(ArrayList<Theatre> arrayList) {
        theatre_array = arrayList;
    }

    @Override
    public void showsAdd(ArrayList arrayList, String s, String e, String n) {
        show_array = arrayList;
        ArrayList<Show> tempArray = new ArrayList<>();
        String start_time = s;
        String end_time = e;
        String delim = "[:]";
        String showName = n;

        String[] startTime = start_time.split(delim);
        String startTimeParse = startTime[0] + startTime[1];
        String[] endTime = end_time.split(delim);
        String endTimeParse = endTime[0] + endTime[1];

        for (int i = 0; i < show_array.size(); i++) {
            Show current = show_array.get(i);

            String showTime = current.getStartTime();
            String[] showStart = showTime.split(delim);
            String startHoursShow = showStart[0];
            String startMinShow = showStart[1];

            showTime = current.getEndTime();
            String[] showEnd = showTime.split(delim);
            String endHoursShow = showEnd[0];
            String endMinShow = showEnd[1];

            int startTimeShow = Integer.parseInt(startHoursShow + startMinShow);
            int endTimeShow = Integer.parseInt(endHoursShow + endMinShow);
            if (current.getTitle().toLowerCase().contains(showName.toLowerCase())) {
                if (Integer.parseInt(startTimeParse) <= startTimeShow) {
                    if (Integer.parseInt(endTimeParse) >= endTimeShow) {
                        String startingtime = startHoursShow + ":" + startMinShow + ":00";
                        String endingtime = endHoursShow + ":" + endMinShow + ":00";
                        tempArray.add(new Show(current.getTitle(), current.getId(), startingtime, endingtime, current.getTheathre(), current.getStatus()));
                    }
                }
            }
        }
        ArrayAdapter<Show> adapter = new ArrayAdapter<Show>(this, R.layout.list_text, tempArray);
        shows.setAdapter(adapter);


    }

    public void getShow(View v) {
        Context context = getApplicationContext();
        String id_single;
        ArrayList<Integer> id = new ArrayList<>();
        Toast toast;
        String date = dateInput.getText().toString();
        String start_time;
        String end_time;
        boolean status = true;


        if (startTimeInput.getText().toString().matches("")) {
            start_time = "00:00:00";
        } else {
            start_time = startTimeInput.getText().toString();
        }
        if (endTimeInput.getText().toString().matches("")) {
            end_time = "24:59:00";
        } else {
            end_time = endTimeInput.getText().toString();
        }

        String name = nameInput.getText().toString();
        int arrayid = movieSpinner.getSelectedItemPosition();
        id_single = theatre_array.get(arrayid).getId();
        if (id_single.equals("1029")) {
            id.add(1012);
            id.add(1002);
            id.add(1015);
            id.add(1016);
            id.add(1017);
            id.add(1041);
            id.add(1018);
            id.add(1019);
            id.add(1021);
            id.add(1022);
        }
        if(id.equals("1029") && !name.matches("")){
            status = false;

        }if(!id.equals("1029")){
            status = true;
        } else if (date.matches("")) {
            Date dateNow = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
            date = sdf.format(dateNow);
        }
        new ReaderXML_Shows(this, date, id, start_time, end_time, status, name).execute();
    }

    class ReaderXML_Theatre extends AsyncTask<Void, ArrayList<Theatre>, ArrayList<Theatre>> {
        MainInterface mainInterface;

        public ReaderXML_Theatre(MainInterface mif) {
            mainInterface = mif;
        }

        protected ArrayList<Theatre> doInBackground(Void... voids) {
            ArrayList<Theatre> theatre_array = new ArrayList<>();

            try {

                String urlString = "https://www.finnkino.fi/xml/TheatreAreas/";
                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                Document doc = builder.parse(urlString);
                doc.getDocumentElement().normalize();
                NodeList nList = doc.getElementsByTagName("TheatreArea");
                for (int i = 0; i < nList.getLength(); i++) {
                    Node node = nList.item(i);

                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        Element element = (Element) node;
                        String id = (element.getElementsByTagName("ID").item(0).getTextContent());
                        String name = (element.getElementsByTagName("Name").item(0).getTextContent());
                        theatre_array.add(new Theatre(name, id));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }


            return theatre_array;
        }

        @Override
        protected void onPostExecute(ArrayList<Theatre> theatre_array) {
            super.onPostExecute(theatre_array);
            mainInterface.spinnerAdd(theatre_array);
            mainInterface.getArray(theatre_array);
        }
    }

    class ReaderXML_Shows extends AsyncTask<Void, ArrayList<Show>, ArrayList<Show>> {
        MainInterface mainInterface;
        String date;
        ArrayList<Integer> id;
        String start_time;
        String end_time;
        boolean status;
        String showName;


        public ReaderXML_Shows(MainInterface mif, String d, ArrayList<Integer> i, String s, String e, boolean b, String n) {
            date = d;
            mainInterface = mif;
            id = i;
            start_time = s;
            end_time = e;
            status = b;
            showName = n;
        }

        @Override
        protected ArrayList<Show> doInBackground(Void... voids) {
            ArrayList<Show> show_array = new ArrayList<>();

            try {
                for(Integer id_single : id) {
                    String urlString = "http://www.finnkino.fi/xml/Schedule/?area=" + id_single + "&dt=" + date;
                    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                    Document doc = builder.parse(urlString);
                    doc.getDocumentElement().normalize();
                    NodeList nList = doc.getElementsByTagName("Show");
                    for (int i = 0; i < nList.getLength(); i++) {
                        Node node = nList.item(i);

                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            String id = (element.getElementsByTagName("ID").item(0).getTextContent());
                            String title = (element.getElementsByTagName("Title").item(0).getTextContent());
                            String fullStartDate = (element.getElementsByTagName("dttmShowStart").item(0).getTextContent());
                            String delim = "[T]";
                            String[] startTime = fullStartDate.split(delim);
                            String fullEndDate = (element.getElementsByTagName("dttmShowEnd").item(0).getTextContent());
                            String theatre = (element.getElementsByTagName("Theatre").item(0).getTextContent());
                            String[] endTime = fullEndDate.split(delim);
                            show_array.add(new Show(title, id, startTime[1], endTime[1], theatre, status));

                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }

            return show_array;
        }

        @Override
        protected void onPostExecute(ArrayList<Show> show_array) {
            mainInterface.showsAdd(show_array, start_time, end_time, showName);
        }
    }
}
