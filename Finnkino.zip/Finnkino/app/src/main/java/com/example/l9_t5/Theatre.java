package com.example.l9_t5;

public class Theatre {
    private String name;
    private String id;

    Theatre(String n, String i) {
        id = i;
        name = n;
    }

    @Override
    public String toString(){
        return name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
