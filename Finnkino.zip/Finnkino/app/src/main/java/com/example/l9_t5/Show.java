package com.example.l9_t5;

public class Show {
    private String title;
    private String id;
    private String startTime;
    private String[] starttime;
    private String[] endtime;
    private String endTime;
    private String theatre;
    private boolean status;

    public Show (String t, String i, String s, String e, String h, boolean st){
        title = t;
        id = i;
        startTime = s;
        endTime = e;
        theatre = h;
        status = st;

        String delim = "[:]";
        starttime = s.split(delim);
        startTime = starttime[0] + ":" + starttime[1];

        endtime = e.split(delim);
        endTime = endtime[0] + ":" + endtime[1];

    }

    @Override
    public String toString(){
        if (status == false) {
            return (theatre + "\n" + title + ":\n" + startTime + " - " + endTime);
        } else {
            return (theatre + "\n" + title + ":\n" + startTime + " - " + endTime);
        }
    }
    public String getTitle(){
        return title;
    }

    public String getId() {
        return id;
    }

    public String getStartTime(){
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getTheathre() {
        return theatre;
    }

    public Boolean getStatus() {
        return status;
    }
}
